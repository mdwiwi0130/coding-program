#include <iostream>
using namespace std;
int main(){
	ios::sync_with_stdio(0), cin.tie(0);
	int n,a,o=0,q=0,mx=0;
	bool s=true;
	cin>>n;
	int m[n+1]={};
	for(;n>0;n--){
		cin>>a;
		if(a==1){
			o++;
			cin>>m[o];
			if(m[o]<m[o-1])
				s=false;
		}
		else if(a==3&&o==0){
			cout<<"empty!";
		}
		else if(a==3){
			if(s==true){
				cout<<m[o];
			}
			else{
				for(int i=o;i>q;i--)
					mx=max(mx,m[i]);
				cout<<mx;
				q=o;
			}
		}
		else if(a==2&&o!=0){
			o--;
			q=0;
			mx=0;
		}
		cout<<"\n";
	}
	return 0;
}

