#include <iostream>
#include <cmath>
using namespace std;
int main(){
	ios::sync_with_stdio(0), cin.tie(0); 
	long long n,x[26]={},y[26]={},o,j;//x==���L,,y==�ƭ� 
	char a;
	for(cin>>n;n>0;n--){
		cin>>a;
		j=a-97;
		cin>>a;
		if(a=='='){
			cin>>y[j];
			x[j]++;
		}
		else if(a=='+'){
			cin>>a;
			cin>>o;
			y[j]+=o;
		}
		else if(a=='-'){
			cin>>a;
			cin>>o;
			y[j]-=o;
		}
	}
	for(int i=0;i<26;i++){
		if(x[i]!=0)
			cout<<char(i+97)<<": "<<y[i]<<"\n";
	}
	return 0;
}

