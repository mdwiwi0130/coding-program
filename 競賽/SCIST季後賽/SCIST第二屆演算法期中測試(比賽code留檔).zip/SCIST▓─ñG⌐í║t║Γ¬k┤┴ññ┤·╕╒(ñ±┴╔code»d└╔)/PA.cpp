#include <iostream>
using namespace std;
int main(){
	ios::sync_with_stdio(0), cin.tie(0);
	long long t,x,n;
	cin>>t>>x>>n;
	if(n%x!=0)
		n=n/x+1;
	else
		n=n/x;
	cout<<n*t;
	return 0;
}

