#include <iostream>
using namespace std;
int main(){
	ios::sync_with_stdio(0), cin.tie(0);
	int n,m;
	cin>>n>>m;
	long long a[m]={};
	for(int i=0;i<m;i++){
		cin>>a[i];
	}
	int o=0;
	char k[2]={'*','#'};
	for(int i=0;i<m;i++){
		for(;a[i]>0;a[i]--){
			cout<<k[i%2];
			o++;
			if(o==n){
				o=0;
				cout<<"\n";
			}
		}
	}
	return 0;
}

